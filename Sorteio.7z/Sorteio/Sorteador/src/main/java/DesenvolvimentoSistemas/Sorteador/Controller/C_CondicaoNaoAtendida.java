package DesenvolvimentoSistemas.Sorteador.Controller;

public class C_CondicaoNaoAtendida extends RuntimeException {
    public C_CondicaoNaoAtendida(String message) {
        super(message);
    }

}
